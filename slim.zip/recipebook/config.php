<?
$config['displayErrorDetails'] = true;
//$config['addContentLengthHeader'] = false;

$config['upload_directory'] = __DIR__ . '/uploads/';

$config['db']['host']   = "localhost";
$config['db']['user']   = "root";
$config['db']['pass']   = "";
$config['db']['dbname'] = "recipe_book";